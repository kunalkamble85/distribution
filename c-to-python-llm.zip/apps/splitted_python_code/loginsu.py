from clearscreen import clear_screen

# Redirect after successful login
def loginsu(username):
    clear_screen()
    print("Fetching account details.....\n")

    input("LOGIN SUCCESSFUL....\nPress enter to continue")