import login

# Successful account creation
def accountcreated():
    print("\nPLEASE WAIT....")
    print("YOUR DATA IS PROCESSING....\n")
    print("ACCOUNT CREATED SUCCESSFULLY....\n")

    input("Press enter to login")
    login.login()